import Love from '@/assets/love.png'
import Call from '@/assets/call.png'
import Wa from '@/assets/wa.png'
import BL from '@/assets/80.png'
import Zan from '@/assets/zan.png'
import Question from '@/assets/question.png'
import Momo from '@/assets/momo.png'
export const mapperEmo = {
	爱你: Love,

	call: Call,

	wa: Wa,

	80: BL,

	赞: Zan,

	问号: Question,

	摸: Momo,
}
