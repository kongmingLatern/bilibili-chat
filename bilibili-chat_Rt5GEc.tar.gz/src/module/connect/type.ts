export interface ConnectProps {
	roomId?: number
	uid?: number
	token?: string
	buvid?: string
	authBody?: any
}
