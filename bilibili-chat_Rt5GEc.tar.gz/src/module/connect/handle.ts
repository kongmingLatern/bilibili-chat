import { CMD } from './const'

export function handlerLiveMsg(cmd: CMD) {
	switch (cmd) {
		case CMD.AREA_RANK_CHANGED:
			break

		default:
			break
	}
}
